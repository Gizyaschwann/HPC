#include <stdio.h>
#include <stdlib.h>
#include "blackbox.h"

int main ()
{
    int n;
    scanf("%d", &n);
    blackbox_init(n);

    const int num_steps = 20000;
    const double h = 2.0 / num_steps; // (b-a)/n = 2/n
/*
    double a = -1.0;
    double b = 1.0;
    double s = 0;
    double x = a;
    double y = blackbox(x);
    s = y;

    x += h;
    y = blackbox(x);
    s += 4 * y;
*/

    double x = -1.0;
    double s = blackbox(x);
    x += h;
    s += 4 * blackbox(x);

    int i;
    for (i = 2; i < num_steps; i+=2){
        x += h;
        s += 2 * blackbox(x);
        x += h;
        s += 4 * blackbox(x);
    }
        /*
        x = b;
        y = blackbox(x);
        s+=y;
        s*=h/3;
        */

    s += blackbox(1.0);
    s*=h/3;

    printf("%.12lf", s);

  return 0;
}
